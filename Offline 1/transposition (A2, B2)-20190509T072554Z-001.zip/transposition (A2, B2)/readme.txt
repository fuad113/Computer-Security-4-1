Please work on your specefied text file. Otherwise you will get zero. 

Each file contains two lines
1st line denotes the ciphertext that you need to decode


2nd line denotes some words that are present in the plaintext. Use the words to find the number of columns (key length) and iterate them to find their ordering